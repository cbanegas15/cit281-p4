const { data } = require('./p4-data');

// Function to get questions
function getQuestions() {
    return data.map(item => item.question);
}

// Function to get answers
function getAnswers() {
    return data.map(item => item.answer);
}

// Function to get a copy of data
function getQuestionsAnswers() {
    return data.map(item => ({...item}));
}

// Function to get a question
function getQuestion(number = "") {
    if(typeof number !== "number" || number < 1 || number > data.length) {
        return { question: "", number: "", error: "Question number must be an integer and within range." };
    }
    return { question: data[number-1].question, number: number, error: "" };
}

// Function to get an answer
function getAnswer(number = "") {
    if(typeof number !== "number" || number < 1 || number > data.length) {
        return { answer: "", number: "", error: "Answer number must be an integer and within range." };
    }
    return { answer: data[number-1].answer, number: number, error: "" };
}

// Function to get a question and an answer
function getQuestionAnswer(number = "") {
    if(typeof number !== "number" || number < 1 || number > data.length) {
        return { question: "", answer: "", number: "", error: "Question number must be an integer and within range." };
    }
    return { question: data[number-1].question, answer: data[number-1].answer, number: number, error: "" };
}

// Module function testing
function testing(category, ...args) {
    console.log(`\n** Testing ${category} **`);
    console.log("-------------------------------");
    for (const o of args) {
        console.log(`-> ${category}${o.d}:`);
        console.log(o.f);
    }
}

// Set a constant to true to test the appropriate function
const testGetQs = true;
const testGetAs = true;
const testGetQsAs = true;
const testGetQ = true;
const testGetA = true;
const testGetQA = true;

// Add testing code at the bottom
if (testGetQs) {
    testing("getQuestions", { d: "()", f: getQuestions() });
}

if (testGetAs) {
    testing("getAnswers", { d: "()", f: getAnswers() });
}

if (testGetQsAs) {
    testing("getQuestionsAnswers", { d: "()", f: getQuestionsAnswers() });
}

if (testGetQ) {
    testing("getQuestion", { d: "()", f: getQuestion() }, { d: "(1)", f: getQuestion(1) });
}

if (testGetA) {
    testing("getAnswer", { d: "()", f: getAnswer() }, { d: "(1)", f: getAnswer(1) });
}

if (testGetQA) {
    testing("getQuestionAnswer", { d: "()", f: getQuestionAnswer() }, { d: "(1)", f: getQuestionAnswer(1) });
}

// Exporting the functions
module.exports = {
    getQuestions,
    getAnswers,
    getQuestionsAnswers,
    getQuestion,
    getAnswer,
    getQuestionAnswer,
  };
  