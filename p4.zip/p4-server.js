// Import Fastify and the module with your functions
const fastify = require('fastify')();
const {
  getQuestions,
  getAnswers,
  getQuestionsAnswers,
  getQuestion,
  getAnswer,
  getQuestionAnswer,
} = require('./p4-module');

// Set up each route

// Route for all questions
fastify.get('/cit/question', (request, reply) => {
  const result = getQuestions();
  reply
    .code(200)
    .header('Content-Type', 'application/json; charset=utf-8')
    .send({ error: "", statusCode: 200, questions: result });
});

// Route for all answers
fastify.get('/cit/answer', (request, reply) => {
  const result = getAnswers();
  reply
    .code(200)
    .header('Content-Type', 'application/json; charset=utf-8')
    .send({ error: "", statusCode: 200, answers: result });
});

// Route for all questions and answers
fastify.get('/cit/questionanswer', (request, reply) => {
  const result = getQuestionsAnswers();
  reply
    .code(200)
    .header('Content-Type', 'application/json; charset=utf-8')
    .send({ error: "", statusCode: 200, questions_answers: result });
});

// Route for specific question
fastify.get('/cit/question/:number', (request, reply) => {
  const { number } = request.params;
  const result = getQuestion(Number(number));
  reply
    .code(200)
    .header('Content-Type', 'application/json; charset=utf-8')
    .send({ error: result.error, statusCode: 200, question: result.question, number: result.number });
});

// Route for specific answer
fastify.get('/cit/answer/:number', (request, reply) => {
  const { number } = request.params;
  const result = getAnswer(Number(number));
  reply
    .code(200)
    .header('Content-Type', 'application/json; charset=utf-8')
    .send({ error: result.error, statusCode: 200, answer: result.answer, number: result.number });
});

// Route for specific question and answer
fastify.get('/cit/questionanswer/:number', (request, reply) => {
  const { number } = request.params;
  const result = getQuestionAnswer(Number(number));
  reply
    .code(200)
    .header('Content-Type', 'application/json; charset=utf-8')
    .send({ error: result.error, statusCode: 200, question: result.question, answer: result.answer, number: result.number });
});

// Unmatched route handler
fastify.all("*", (request, reply) => {
  reply
    .code(404)
    .header('Content-Type', 'application/json; charset=utf-8')
    .send({ error: "Route not found", statusCode: 404 });
});

// Start the server
const start = async () => {
  try {
    await fastify.listen(3000);
    console.log(`server listening on ${fastify.server.address().port}`);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
};

start();
